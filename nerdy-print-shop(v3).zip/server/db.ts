import { eq, and, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { 
  InsertUser, users, 
  products, InsertProduct, Product,
  categories, InsertCategory, Category,
  cartItems, InsertCartItem, CartItem,
  orders, InsertOrder, Order,
  orderItems, InsertOrderItem, OrderItem,
  generatedModels, InsertGeneratedModel, GeneratedModel,
  productImages, InsertProductImage, ProductImage,
  reviews, InsertReview, Review,
  reviewLikes, InsertReviewLike, ReviewLike,
  wishlistItems, InsertWishlistItem, WishlistItem,
  coupons, InsertCoupon, Coupon,
  couponUsages, InsertCouponUsage, CouponUsage,
  adminPermissions, InsertAdminPermission, AdminPermission
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ============ USER HELPERS ============
export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod", "phone"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function updateUserProfile(userId: number, data: { name?: string; email?: string; phone?: string }) {
  const db = await getDb();
  if (!db) return;
  await db.update(users).set(data).where(eq(users.id, userId));
}

// ============ CATEGORY HELPERS ============
export async function getAllCategories() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(categories);
}

export async function createCategory(data: InsertCategory) {
  const db = await getDb();
  if (!db) return;
  await db.insert(categories).values(data);
}

// ============ PRODUCT HELPERS ============
export async function getAllProducts(activeOnly = true) {
  const db = await getDb();
  if (!db) return [];
  if (activeOnly) {
    return db.select().from(products).where(eq(products.isActive, true));
  }
  return db.select().from(products);
}

export async function getPopularProducts(limit = 10) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(products)
    .where(and(eq(products.isActive, true), eq(products.isPopular, true)))
    .limit(limit);
}

export async function getProductById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(products).where(eq(products.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getProductBySlug(slug: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(products).where(eq(products.slug, slug)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function createProduct(data: InsertProduct) {
  const db = await getDb();
  if (!db) return;
  await db.insert(products).values(data);
}

export async function updateProduct(id: number, data: Partial<InsertProduct>) {
  const db = await getDb();
  if (!db) return;
  await db.update(products).set(data).where(eq(products.id, id));
}

export async function deleteProduct(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(products).where(eq(products.id, id));
}

// ============ CART HELPERS ============
export async function getCartItems(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(cartItems).where(eq(cartItems.userId, userId));
}

export async function getCartItemsWithProducts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  
  const items = await db.select().from(cartItems).where(eq(cartItems.userId, userId));
  const itemsWithProducts = await Promise.all(
    items.map(async (item) => {
      const product = await getProductById(item.productId);
      return { ...item, product };
    })
  );
  return itemsWithProducts.filter(item => item.product);
}

export async function addToCart(userId: number, productId: number, quantity = 1) {
  const db = await getDb();
  if (!db) return;
  
  const existing = await db.select().from(cartItems)
    .where(and(eq(cartItems.userId, userId), eq(cartItems.productId, productId)))
    .limit(1);
  
  if (existing.length > 0) {
    await db.update(cartItems)
      .set({ quantity: existing[0].quantity + quantity })
      .where(eq(cartItems.id, existing[0].id));
  } else {
    await db.insert(cartItems).values({ userId, productId, quantity });
  }
}

export async function updateCartItemQuantity(userId: number, itemId: number, quantity: number) {
  const db = await getDb();
  if (!db) return;
  
  if (quantity <= 0) {
    await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.userId, userId)));
  } else {
    await db.update(cartItems)
      .set({ quantity })
      .where(and(eq(cartItems.id, itemId), eq(cartItems.userId, userId)));
  }
}

export async function removeFromCart(userId: number, itemId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(cartItems).where(and(eq(cartItems.id, itemId), eq(cartItems.userId, userId)));
}

export async function clearCart(userId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(cartItems).where(eq(cartItems.userId, userId));
}

// ============ ORDER HELPERS ============
export async function createOrder(data: InsertOrder) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(orders).values(data);
  return result[0].insertId;
}

export async function createOrderItems(items: InsertOrderItem[]) {
  const db = await getDb();
  if (!db) return;
  await db.insert(orderItems).values(items);
}

export async function getOrdersByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).where(eq(orders.userId, userId)).orderBy(desc(orders.createdAt));
}

export async function getOrderById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(orders).where(eq(orders.id, id)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function getOrderItems(orderId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
}

export async function updateOrderStatus(id: number, status: Order["status"]) {
  const db = await getDb();
  if (!db) return;
  await db.update(orders).set({ status }).where(eq(orders.id, id));
}

export async function getAllOrders() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(orders).orderBy(desc(orders.createdAt));
}

export async function deleteOrder(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(orders).set({ isDeleted: true }).where(eq(orders.id, id));
}

export async function restoreOrder(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.update(orders).set({ isDeleted: false }).where(eq(orders.id, id));
}

// ============ GENERATED MODELS HELPERS ============
export async function createGeneratedModel(data: InsertGeneratedModel) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(generatedModels).values(data);
  return result[0].insertId;
}

export async function getGeneratedModelsByUser(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(generatedModels).where(eq(generatedModels.userId, userId)).orderBy(desc(generatedModels.createdAt));
}

export async function updateGeneratedModel(id: number, data: Partial<InsertGeneratedModel>) {
  const db = await getDb();
  if (!db) return;
  await db.update(generatedModels).set(data).where(eq(generatedModels.id, id));
}


// ============ PRODUCT IMAGES (GALLERY) HELPERS ============
export async function getProductImages(productId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(productImages).where(eq(productImages.productId, productId)).orderBy(productImages.sortOrder);
}

export async function addProductImage(data: InsertProductImage) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(productImages).values(data);
  return result[0].insertId;
}

export async function deleteProductImage(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(productImages).where(eq(productImages.id, id));
}

// ============ REVIEWS HELPERS ============
export async function getProductReviews(productId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(reviews).where(and(eq(reviews.productId, productId), eq(reviews.isApproved, true))).orderBy(desc(reviews.createdAt));
}

export async function createReview(data: InsertReview) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(reviews).values(data);
  return result[0].insertId;
}

export async function getUserReviewForProduct(userId: number, productId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(reviews).where(and(eq(reviews.userId, userId), eq(reviews.productId, productId))).limit(1);
  return result[0];
}

export async function getProductAverageRating(productId: number) {
  const db = await getDb();
  if (!db) return { average: 0, count: 0 };
  const result = await db.select().from(reviews).where(and(eq(reviews.productId, productId), eq(reviews.isApproved, true)));
  if (result.length === 0) return { average: 0, count: 0 };
  const sum = result.reduce((acc, r) => acc + r.rating, 0);
  return { average: sum / result.length, count: result.length };
}

// ============ REVIEW LIKES HELPERS ============
export async function toggleReviewLike(reviewId: number, userId: number) {
  const db = await getDb();
  if (!db) return false;
  
  const existing = await db.select().from(reviewLikes).where(and(eq(reviewLikes.reviewId, reviewId), eq(reviewLikes.userId, userId))).limit(1);
  
  if (existing.length > 0) {
    await db.delete(reviewLikes).where(eq(reviewLikes.id, existing[0].id));
    const likesCount = await getReviewLikesCount(reviewId);
    await db.update(reviews).set({ likesCount }).where(eq(reviews.id, reviewId));
    return false;
  } else {
    await db.insert(reviewLikes).values({ reviewId, userId });
    const likesCount = await getReviewLikesCount(reviewId);
    await db.update(reviews).set({ likesCount }).where(eq(reviews.id, reviewId));
    return true;
  }
}

export async function getReviewLikesCount(reviewId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db.select().from(reviewLikes).where(eq(reviewLikes.reviewId, reviewId));
  return result.length;
}

export async function hasUserLikedReview(reviewId: number, userId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select().from(reviewLikes).where(and(eq(reviewLikes.reviewId, reviewId), eq(reviewLikes.userId, userId))).limit(1);
  return result.length > 0;
}

// ============ WISHLIST HELPERS ============
export async function getWishlist(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(wishlistItems).where(eq(wishlistItems.userId, userId)).orderBy(desc(wishlistItems.createdAt));
}

export async function getWishlistWithProducts(userId: number) {
  const db = await getDb();
  if (!db) return [];
  const items = await db.select().from(wishlistItems).where(eq(wishlistItems.userId, userId)).orderBy(desc(wishlistItems.createdAt));
  const result = [];
  for (const item of items) {
    const product = await db.select().from(products).where(eq(products.id, item.productId)).limit(1);
    if (product[0]) {
      result.push({ ...item, product: product[0] });
    }
  }
  return result;
}

export async function addToWishlist(userId: number, productId: number) {
  const db = await getDb();
  if (!db) return false;
  const existing = await db.select().from(wishlistItems).where(and(eq(wishlistItems.userId, userId), eq(wishlistItems.productId, productId))).limit(1);
  if (existing.length > 0) return false;
  await db.insert(wishlistItems).values({ userId, productId });
  return true;
}

export async function removeFromWishlist(userId: number, productId: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(wishlistItems).where(and(eq(wishlistItems.userId, userId), eq(wishlistItems.productId, productId)));
}

export async function isInWishlist(userId: number, productId: number) {
  const db = await getDb();
  if (!db) return false;
  const result = await db.select().from(wishlistItems).where(and(eq(wishlistItems.userId, userId), eq(wishlistItems.productId, productId))).limit(1);
  return result.length > 0;
}

// ============ COUPONS HELPERS ============
export async function getAllCoupons() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(coupons).orderBy(desc(coupons.createdAt));
}

export async function getCouponByCode(code: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(coupons).where(eq(coupons.code, code.toUpperCase())).limit(1);
  return result[0];
}

export async function createCoupon(data: InsertCoupon) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.insert(coupons).values({ ...data, code: data.code.toUpperCase() });
  return result[0].insertId;
}

export async function updateCoupon(id: number, data: Partial<InsertCoupon>) {
  const db = await getDb();
  if (!db) return;
  if (data.code) data.code = data.code.toUpperCase();
  await db.update(coupons).set(data).where(eq(coupons.id, id));
}

export async function deleteCoupon(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(coupons).where(eq(coupons.id, id));
}

export async function incrementCouponUsage(id: number) {
  const db = await getDb();
  if (!db) return;
  const coupon = await db.select().from(coupons).where(eq(coupons.id, id)).limit(1);
  if (coupon[0]) {
    await db.update(coupons).set({ currentUses: coupon[0].currentUses + 1 }).where(eq(coupons.id, id));
  }
}

export async function validateCoupon(code: string, orderTotal: number) {
  const coupon = await getCouponByCode(code);
  if (!coupon) return { valid: false, error: 'Cupom não encontrado' };
  if (!coupon.isActive) return { valid: false, error: 'Cupom inativo' };
  if (coupon.maxUses && coupon.currentUses >= coupon.maxUses) return { valid: false, error: 'Cupom esgotado' };
  if (coupon.startsAt && new Date(coupon.startsAt) > new Date()) return { valid: false, error: 'Cupom ainda não está válido' };
  if (coupon.expiresAt && new Date(coupon.expiresAt) < new Date()) return { valid: false, error: 'Cupom expirado' };
  if (coupon.minOrderValue && orderTotal < parseFloat(coupon.minOrderValue)) {
    return { valid: false, error: `Valor mínimo do pedido: R$ ${coupon.minOrderValue}` };
  }
  return { valid: true, coupon };
}

export async function recordCouponUsage(data: InsertCouponUsage) {
  const db = await getDb();
  if (!db) return;
  await db.insert(couponUsages).values(data);
}

export async function getCouponUsageHistory(couponId: number) {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(couponUsages).where(eq(couponUsages.couponId, couponId)).orderBy(desc(couponUsages.createdAt));
}

// ============ PERMISSIONS ============

export async function getAllPermissions() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(adminPermissions).orderBy(desc(adminPermissions.createdAt));
}

export async function getPermissionByEmail(email: string) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(adminPermissions).where(eq(adminPermissions.email, email.toLowerCase())).limit(1);
  return result[0] || null;
}

export async function createPermission(data: InsertAdminPermission) {
  const db = await getDb();
  if (!db) return;
  await db.insert(adminPermissions).values({
    ...data,
    email: data.email.toLowerCase(),
  });
}

export async function updatePermission(id: number, data: Partial<InsertAdminPermission>) {
  const db = await getDb();
  if (!db) return;
  await db.update(adminPermissions).set(data).where(eq(adminPermissions.id, id));
}

export async function deletePermission(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(adminPermissions).where(eq(adminPermissions.id, id));
}
